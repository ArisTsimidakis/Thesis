virtual void FUN1(VAR1* VAR2,
                            VAR3* VAR4,
                            int VAR5) {
    VAR6.FUN2(new FUN3(VAR4, VAR5, VAR7));
  }