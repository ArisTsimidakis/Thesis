static void FUN1(const VAR1::VAR2<VAR1::VAR3>& VAR4)
{
    if (FUN2(VAR4.FUN3() < 1)) {
        FUN4(VAR5::FUN5("", "", VAR5::FUN6(1, VAR4.FUN3())), VAR4.FUN7());
        return;
    }
    VAR6* VAR7 = VAR8::FUN8(VAR4.FUN9());
    FUN10(VAR9<VAR10>, VAR11, VAR10::FUN11(FUN12(VAR4[0], VAR4.FUN7())));
    VAR7->FUN13(VAR11);
}