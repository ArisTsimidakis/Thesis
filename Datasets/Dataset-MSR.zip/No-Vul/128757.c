VAR1* VAR2::FUN1(VAR3* VAR4, VAR5& VAR6)
{
    if (VAR7) {
        VAR6.FUN2("");
        return nullptr;
    }
    return new FUN3(VAR4, this);
}