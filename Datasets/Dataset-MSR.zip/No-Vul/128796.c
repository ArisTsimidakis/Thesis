void VAR1::FUN1(EGLSyncKHR VAR2,
                                             VAR3* VAR4) {
  FUN2(FUN3(), VAR2);
  VAR4->VAR5 = true;
  FUN4();
}