bool FUN1(const VAR1& VAR2) {
  VAR3::VAR4::FUN2();
  return FUN3(VAR2.FUN4().FUN5(), VAR5) == 0;
}