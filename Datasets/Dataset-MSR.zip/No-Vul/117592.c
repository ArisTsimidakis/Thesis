void VAR1::FUN1(VAR2* VAR3, double VAR4, bool VAR5) {
  FUN2(!VAR6);
  FUN2(VAR3);
  VAR6 = VAR3;
  FUN3(VAR7);
  VAR7->FUN4(0.0, 100.0);
  VAR7->FUN5(true);
  FUN5(true);
  FUN6(VAR4);
  FUN7(VAR5);
}