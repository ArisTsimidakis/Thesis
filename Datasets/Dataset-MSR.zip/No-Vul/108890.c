void VAR1::FUN1(VAR2::VAR3* VAR4, VAR2::VAR3* VAR5) {
  if (VAR6.FUN2()) {
    
    
    
    
    VAR2::Rect VAR7 = VAR6.FUN3();
    *VAR4 = VAR7;
    *VAR5 = VAR7;
    return;
  }
  VAR8::FUN1(VAR4, VAR5);
}