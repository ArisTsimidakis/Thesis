VAR1::VAR2* FUN1() {
  VAR3::VAR4* VAR5 =
      new VAR3::FUN2();
  VAR5->FUN3();
  return VAR5;
}