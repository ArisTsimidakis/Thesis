void VAR1::FUN1(VAR2* VAR3) {
  FUN2(VAR3);
  
  VAR4--;
  delete VAR3;
}