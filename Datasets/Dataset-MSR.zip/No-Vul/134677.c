VAR1::Vector2dF VAR2::FUN1() {
  return VAR3;
}