VAR1::FUN1(VAR2& VAR3)
    : FUN2(&VAR3),
      FUN3(VAR4::FUN4()),
      FUN5(0),
      FUN6(false),
      
      
      FUN7(false),
      FUN8(VAR5::FUN9(new VAR6)),
      FUN10(false),
      FUN11(VAR7),
      FUN12(false) {}