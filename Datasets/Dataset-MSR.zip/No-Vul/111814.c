void VAR1::FUN1() {
  if (!VAR2)
    return;

  FUN2(VAR3::FUN3(), VAR4);

  
  VAR5.FUN4();
  VAR2->FUN5();
}