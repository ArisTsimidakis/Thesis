void FUN1()
    {
        FUN2(VAR1);
        FUN3(VAR1);
        VAR1 = 0;
        FUN4(VAR2);
    }