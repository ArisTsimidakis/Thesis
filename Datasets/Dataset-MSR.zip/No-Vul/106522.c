void VAR1::FUN1(const VAR2& VAR3)
{
    if (!FUN2())
        return;

    FUN3()->send(VAR4::VAR5::FUN4(VAR3), VAR6);
}