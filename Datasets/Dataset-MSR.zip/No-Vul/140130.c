void VAR1::FUN1(VAR2* VAR3) {
  if (FUN2() &&
      VAR4.FUN3(VAR3)) {
    if (VAR3->FUN4() != VAR2::VAR5)
      FUN5(static_cast<VAR6>(FUN2()->FUN6()));
  } else {
    
    
    
    
    
    
    
    
    if (FUN7() &&
        VAR3->FUN4() == VAR2::VAR7) {
      FUN7()->FUN8();
    }
  }
}