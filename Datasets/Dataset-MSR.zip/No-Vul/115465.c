bool VAR1::FUN1(WKBundleRangeHandleRef VAR2)
{
    if (!VAR3::FUN2().FUN3())
        return true;

    if (VAR3::FUN2().FUN4()->FUN5()) {
        StringBuilder VAR4;
        VAR4.FUN6("");
        VAR4.FUN7(FUN8(VAR5, VAR6.FUN9(), VAR2));
        VAR4.FUN7('');
        VAR3::FUN2().FUN10(VAR4.FUN11());
    }
    return VAR3::FUN2().FUN4()->FUN12();
}