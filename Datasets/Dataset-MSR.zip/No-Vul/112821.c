bool VAR1::FUN1(VAR2::VAR3* VAR4) {
  
  
  
  VAR5::WebPreferences VAR6 = FUN2()->FUN3();
  VAR6.VAR7 = false;
  VAR6.VAR8 = false;

  VAR9 = VAR10::FUN4(this);
  VAR6.FUN5(VAR9);
  VAR9->FUN6(this);

  VAR11->VAR12.FUN7();  

  VAR13::string VAR14 = VAR4->FUN8().FUN9();
  VAR13::string VAR15 = "";
  VAR15.FUN10(VAR14);
  VAR16 FUN11(VAR15);

  
  
  VAR9->FUN12()->FUN13(FUN14(VAR17));

  return true;
}