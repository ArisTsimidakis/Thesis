bool FUN1(const VAR1& VAR2,
                               const VAR3& VAR4) {
  
  if (!VAR2.FUN2().FUN3())
    return false;

  
  
  if (VAR2.FUN4().FUN5() || VAR4.FUN5())
    return false;

  return true;
}