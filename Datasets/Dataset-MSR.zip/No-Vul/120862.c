void VAR1::FUN1() {
  
  
  
  
  VAR2* VAR3 = FUN2();
  VAR4* VAR5 = VAR6::FUN3(VAR7);
  if (VAR5->FUN4()) {
    VAR5->FUN4()->FUN5();
  } else {
    FUN6();
    if (VAR3) {
      
      if (VAR8) {
        FUN7();
      } else {
        VAR9::FUN8(VAR10, VAR9::VAR11);
      }
    } else {
      
      FUN9();
      VAR9::FUN10(VAR10);
    }
  }
}