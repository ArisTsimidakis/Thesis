GLenum VAR1::FUN1() {
  GLenum VAR2 = FUN2();
  if (VAR2 != VAR3) {
    FUN3(VAR2, "");
  }
  return VAR2;
}