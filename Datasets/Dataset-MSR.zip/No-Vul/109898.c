void VAR1::FUN1() {
  
  
  if (VAR2[VAR3] == this)
    VAR2[VAR3] = NULL;

  VAR4->FUN1();
}