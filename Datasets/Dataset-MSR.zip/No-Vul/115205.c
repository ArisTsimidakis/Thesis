VAR1::VAR2 FUN1() {
    
    
    return VAR3::FUN1();
  }