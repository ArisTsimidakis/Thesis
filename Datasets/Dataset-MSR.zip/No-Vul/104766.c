void VAR1::FUN1(
    const VAR2& VAR3) {
  if (VAR4::FUN2(VAR3.VAR5) ==
      VAR4::VAR6) {
    
    return;
  }

  
  
  
  
  FUN3(FUN4()) << ""
                                  << "";
  VAR7* VAR8 = new FUN5(*FUN4());
  VAR8->FUN6(VAR3.VAR9);
  FUN7(VAR8, false);
}