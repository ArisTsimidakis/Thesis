FUN1(const VAR1& VAR2, const VAR1& VAR3)
        : FUN2(VAR2.copy())
        , FUN3(VAR3.copy())
    {
    }