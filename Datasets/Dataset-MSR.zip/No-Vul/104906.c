void VAR1::FUN1(
    VAR2* VAR3,
    unsigned long long VAR4,
    unsigned long long VAR5) {
  
  VAR6 = static_cast<VAR7>(VAR4);
  VAR8 = static_cast<VAR7>(VAR5);
  FUN2();
}