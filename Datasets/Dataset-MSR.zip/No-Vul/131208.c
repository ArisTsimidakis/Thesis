static void FUN1(const VAR1::VAR2<VAR1::VAR3>& VAR4)
{
    FUN2("", "");
    VAR5::FUN3(VAR4);
    FUN2("", "");
}