VAR1::~FUN1() {
#ifdef VAR2
  VAR3::VAR4::FUN2()->FUN3(NULL);
#endif

  VAR5->FUN4(VAR6.FUN5());
  VAR5->FUN4(VAR7.FUN5());

  
  
  
  
  
  
  
  
  VAR5->FUN6();
  VAR8.FUN7()->FUN8(NULL);
}