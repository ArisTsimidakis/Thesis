bool VAR1::FUN1(VAR2::VAR3)
{
    return false;
}