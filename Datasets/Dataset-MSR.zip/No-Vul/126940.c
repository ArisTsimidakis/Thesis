virtual ~FUN1() {
    if (VAR1)
      VAR1->VAR2->FUN2();
  }