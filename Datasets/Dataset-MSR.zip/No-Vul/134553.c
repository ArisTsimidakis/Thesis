void VAR1::FUN1(const VAR2& VAR3) {
  if (VAR4)
    VAR4->FUN2();
  if (VAR5) {
    VAR5->FUN1(VAR3);
    
  }
}