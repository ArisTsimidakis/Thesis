bool FUN1(VAR1<VAR2::VAR3> VAR4,
             const VAR5::VAR6& VAR7) {
    return VAR4->FUN2(
        VAR7,
        FUN3(this, &VAR8::VAR9));
  }