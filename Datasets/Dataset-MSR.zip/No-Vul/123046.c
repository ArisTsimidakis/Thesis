void VAR1::FUN1(const VAR2::VAR3& VAR4,
                                                  const VAR2::VAR5& VAR6,
                                                  const VAR2::VAR7& VAR8) {
  if (VAR9) {
    
    
    
    VAR10 = true;
    return;
  }

  
  
  
  VAR11* VAR12 = VAR13::FUN2(this);
  if (!VAR12 || (VAR12->FUN3() != VAR8))
    return;
  VAR12->FUN4(VAR4, VAR6, VAR8);
}