void FUN1() {
    VAR1->FUN2();
  }