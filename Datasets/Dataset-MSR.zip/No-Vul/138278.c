void VAR1::remove(VAR2* VAR3) {
  if (!VAR3)
    return;

  AXID VAR4 = VAR5.FUN1(VAR3);
  remove(VAR4);
  VAR5.FUN2(VAR3);
}