bool VAR1::FUN1() const {
  return VAR2->FUN1();
}