VAR1::VAR2 FUN1() {
    VAR1::EntitySpecifics VAR3;
    FUN2(VAR4::VAR5, &VAR3);
    return VAR3;
  }