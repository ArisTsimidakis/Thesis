static void FUN1(const VAR1::VAR2<VAR1::VAR3>& VAR4)
{
    VAR5* VAR6 = VAR7::FUN2(VAR4.FUN3());
    String VAR8 = VAR6->FUN4(VAR9::VAR10);
    if (VAR8.FUN5()) {
        ;
    } else if (FUN6(VAR8, "")) {
        VAR8 = "";
    } else if (FUN6(VAR8, "")) {
        VAR8 = "";
    } else if (FUN6(VAR8, "")) {
        VAR8 = "";
    } else {
        VAR8 = "";
    }
    FUN7(VAR4, VAR8, VAR4.FUN8());
}