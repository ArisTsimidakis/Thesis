void FUN1(struct VAR1 *VAR2)
{
	VAR2->VAR3++;
	FUN2(4, "",
	       VAR2, VAR2->VAR3);
}