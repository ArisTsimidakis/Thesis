const VAR1& VAR2::FUN1() const {
  return FUN2(VAR3);
}