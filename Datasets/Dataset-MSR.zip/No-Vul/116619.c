VAR1::NativeViewId VAR2::FUN1() {
  return FUN2();
}