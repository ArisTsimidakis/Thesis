bool VAR1::FUN1() {
  return VAR2;
}