void FUN1(const VAR1::VAR2& VAR3)
    {
        FUN2(VAR3.FUN3().FUN4() == VAR1::VAR4);

        FUN5(static_cast<VAR5>(VAR6));
        FUN6(VAR3.FUN3().FUN7());
        
        
        FUN2(!(VAR3.FUN3().FUN8()->FUN9() % 8));
        FUN10(VAR3.FUN3().FUN8()->FUN9() / 8);
    }