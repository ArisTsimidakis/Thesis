void VAR1::FUN1()
{
    if (VAR2->VAR3->FUN2())
        VAR2->VAR3->FUN3();
}