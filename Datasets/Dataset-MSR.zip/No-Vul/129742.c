void VAR1::FUN1(bool VAR2)
{
    if (VAR2 == VAR3)
        return;

    VAR3 = VAR2;

    if (!VAR3)
        return;

    FUN2();
}