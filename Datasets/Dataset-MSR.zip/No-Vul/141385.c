FUN1() {
  for (auto& VAR1 : FUN2())
    VAR1->FUN3();
  FUN2().FUN4();
}