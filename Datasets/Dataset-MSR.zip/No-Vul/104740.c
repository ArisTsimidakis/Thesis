bool FUN1(const VAR1& VAR2, const VAR1& VAR3) {
  if (VAR2 == VAR3 || !VAR3.FUN2()) {
    
    
    
    
    
    
    return false;
  }

  VAR4::VAR5<char> VAR6;
  VAR6.FUN3();
  return VAR2.FUN4(VAR6) ==
      VAR3.FUN4(VAR6);
}