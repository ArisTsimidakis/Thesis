VAR1::VAR2* VAR1::FUN1(
    int VAR3, int VAR4) {
  FUN2(VAR5::FUN3(VAR5::VAR6));

  VAR7::iterator VAR8 = VAR9.FUN4(
      FUN5(VAR3, VAR4));
  if (VAR8 != VAR9.FUN6())
    return VAR8->VAR10;
  return NULL;
}