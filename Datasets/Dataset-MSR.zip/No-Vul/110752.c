void VAR1::FUN1(VAR1* VAR2) {
  const size_t VAR3 = VAR4 - FUN2();
  const size_t VAR5 =
      VAR2->VAR4 - VAR2->FUN2();
  VAR6.FUN3(VAR2->VAR6);
  VAR4 = FUN2() + VAR5;
  VAR2->VAR4 = VAR2->FUN2() + VAR3;
  VAR7.FUN1(&(VAR2->VAR7));
}