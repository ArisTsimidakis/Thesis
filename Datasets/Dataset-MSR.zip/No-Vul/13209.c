VAR1::FUN1(VAR2 , VAR3* VAR4,
                            VAR5 , VAR6* )
{
    

    if (VAR7) {
        
        
        
        
        return VAR8;
    }
    VAR9 = VAR4->VAR10;

    if (!VAR9.FUN2() && VAR11) {
        return FUN3();
    }

    return VAR12;
}