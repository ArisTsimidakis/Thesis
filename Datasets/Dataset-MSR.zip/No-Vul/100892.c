string16 VAR1::VAR2::FUN1() const {
  FUN2(VAR3, VAR4);
  return VAR5::FUN3(
      VAR6,
      FUN4(VAR7));
}