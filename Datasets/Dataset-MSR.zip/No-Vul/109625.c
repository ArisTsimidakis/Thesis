VAR1<VAR2> VAR3::FUN1(VAR4* VAR5, unsigned VAR6, VAR1<VAR7> VAR8, bool VAR9, VAR10& VAR11)
{
    FUN2(VAR9);
    if (!VAR5) {
        VAR11.FUN3(VAR12);
        return 0;
    }
    return VAR2::FUN4(VAR5, VAR6, VAR8);
}