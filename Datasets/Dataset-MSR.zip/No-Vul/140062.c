void VAR1::FUN1() {
  if (FUN2())
    FUN2()->FUN3(VAR2::VAR3);
}