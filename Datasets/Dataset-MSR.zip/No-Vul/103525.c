void VAR1::FUN1(VAR2::ModelType VAR3) {
  VAR4* VAR5 = FUN2(VAR3);
  FUN3(VAR5);
  
  *VAR5 = FUN4();
}