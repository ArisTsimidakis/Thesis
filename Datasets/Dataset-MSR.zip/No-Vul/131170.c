static void FUN1(VAR1::VAR2<VAR1::VAR3>, const VAR1::VAR4<VAR1::VAR5>& VAR6)
{
    FUN2("", "");
    VAR7* VAR8 = VAR7::FUN3(VAR6.FUN4()->FUN5());
    if (VAR8 && VAR8->FUN6())
        VAR8->FUN6()->FUN7("", 0, 0, "");
    VAR9::FUN8(VAR6);
    FUN2("", "");
}