virtual bool FUN1() {
    VAR1 = true;
    FUN2("", 1);
    
    VAR2->FUN3()->FUN4(VAR3::VAR4, false);
    return true;
  }