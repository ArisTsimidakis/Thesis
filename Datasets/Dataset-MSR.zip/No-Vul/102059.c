string16 VAR1::FUN1() const {
  FUN2(FUN3());
  return FUN4(VAR2->FUN5()->FUN1());
}