bool VAR1::FUN1() {
  
  
  if (VAR2 != VAR3)
    return VAR2 != VAR4;

  int VAR5;
  if (VAR6 ==
      FUN2(&VAR5))
    return true;

  
  
  VAR2 = VAR4;
  VAR7->FUN3();

  
  
  return false;
}