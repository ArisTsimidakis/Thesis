void FUN1(VAR1* VAR2)
{
    FUN2("", VAR2);
    FUN3(VAR2, "", 0);
}