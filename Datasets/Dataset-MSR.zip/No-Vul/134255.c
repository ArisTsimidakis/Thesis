VAR1::NativeView VAR2::FUN1() const {
  return FUN2()->FUN1();
}