VAR1::VAR2::FUN1(Type VAR3, VAR4* VAR5)
    : FUN2(VAR3),
      FUN3(VAR5),
      FUN4(VAR6),
      FUN5(VAR7),
      FUN6(VAR8::VAR9),
      FUN7(false),
      FUN8(NULL) {
}