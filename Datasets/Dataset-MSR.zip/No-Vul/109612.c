VAR1<VAR2> VAR3::FUN1(VAR4* VAR5, unsigned VAR6, VAR7& VAR8)
{
    if (!VAR5) {
        VAR8.FUN2(VAR9);
        return 0;
    }
    
    
    return VAR2::FUN3(VAR5, VAR6, VAR1<VAR10>());
}