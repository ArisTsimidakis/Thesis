void VAR1::FUN1(LayoutUnit VAR2)
{
    FUN2(VAR2 >= 0);
    FUN3().VAR3 = VAR2;
}