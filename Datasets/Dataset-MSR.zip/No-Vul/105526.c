void FUN1(VAR1* VAR2)
{
    FUN2(FUN3(VAR2));

    if (FUN4(VAR2))
        FUN5(VAR2, VAR3[VAR4], 0);
}