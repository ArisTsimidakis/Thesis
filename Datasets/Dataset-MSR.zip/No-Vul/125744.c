void VAR1::FUN1(
    int64 VAR2,
    int64 VAR3,
    bool VAR4,
    const VAR5& VAR6,
    bool VAR7,
    bool VAR8,
    VAR9* VAR10) {
  if (!VAR4)
    return;

  
  
  
  if (!VAR7)
    FUN2();
  FUN3();
}