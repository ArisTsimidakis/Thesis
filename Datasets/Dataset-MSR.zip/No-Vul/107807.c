void VAR1::FUN1() {
  VAR2::FUN1(
      VAR3, VAR4::VAR5);
}