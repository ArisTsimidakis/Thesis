static bool FUN1(const VAR1& VAR2) {
  if (VAR2.FUN2() < 2)
    return false;
  return VAR2[0] == '';
}