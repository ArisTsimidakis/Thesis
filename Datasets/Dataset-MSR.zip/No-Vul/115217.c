bool VAR1::FUN1() const {
  long VAR2 = FUN2();
  CHARRANGE VAR3;
  FUN3(VAR3);
  return VAR3.VAR4 == VAR3.VAR5 && VAR3.VAR4 == VAR2;
}