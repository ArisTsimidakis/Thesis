void VAR1::FUN1() {
  if (VAR2 != 0) {
    VAR3 FUN2("",
                                       VAR4->FUN3());
    FUN4(1, &VAR2);
    VAR2 = 0;
  }
  VAR5.FUN5(VAR6);
  VAR6 = 0;
}