void VAR1::FUN1(const VAR2&, float)
{ 
    FUN2(); 
}