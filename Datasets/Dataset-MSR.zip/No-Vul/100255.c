VAR1::string VAR2::FUN1() const {
  
  switch (VAR3) {
    case VAR4:
      return "";
      break;
    case VAR5:
      return "";
      break;
    case VAR6:
      return "";
      break;
    case VAR7:
      return "";
      break;
    case VAR8:
      return "";
      break;
    case VAR9:
      return "";
      break;
    case VAR10:
      return "";
      break;
    case VAR11:
      return "";
      break;
    case VAR12:
      return "";
      break;
    default:
      return VAR13::FUN2(
          VAR14);
      break;
  }
}