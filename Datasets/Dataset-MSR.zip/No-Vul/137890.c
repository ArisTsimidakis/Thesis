void VAR1::FUN1() {
  FUN2(FUN3().FUN4() ? VAR2 : VAR3);
  FUN5();
}