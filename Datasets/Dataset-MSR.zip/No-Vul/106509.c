void VAR1::FUN1(uint64_t VAR2, const VAR3& VAR4, const VAR3& VAR5, VAR6::VAR7* VAR8)
{
    FUN2();

    VAR9<VAR10> VAR11;
    VAR12 FUN3(VAR11, FUN4());
    if (!VAR8->FUN5(VAR13))
        return;

    VAR14* VAR15 = FUN6()->FUN7(VAR2);
    FUN8(VAR15);

    VAR15->FUN9(VAR5);

    VAR15->FUN10(VAR4);
    VAR16.FUN1(this, VAR15, VAR11.FUN11());
}