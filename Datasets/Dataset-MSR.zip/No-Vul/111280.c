VAR1::VAR2::VAR3* VAR4::FUN1() const
{
    return VAR5->FUN2();
}