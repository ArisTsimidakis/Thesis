VAR1::FUN1(VAR2<VAR3> VAR4, VAR5& VAR6)
    : FUN2(false)
    , FUN3(false)
    , FUN4(false)
    , FUN5(VAR4)
    , FUN6(VAR6)
    , FUN7(nullptr)
    , FUN8(nullptr)
    , FUN9(FUN10(VAR7::FUN11()->FUN12()))
    , FUN13(FUN10(VAR7::FUN11()->FUN12()))
{
    VAR8 FUN14(FUN15());
    FUN16().FUN17(this);
}