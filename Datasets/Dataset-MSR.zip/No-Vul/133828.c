void FUN1(
    VAR1::VAR2<VAR3::VAR4::VAR5> VAR6) {
  
  
  
  
  new VAR3::FUN2(VAR6.FUN3());
}