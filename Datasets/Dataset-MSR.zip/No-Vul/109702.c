VAR1* VAR2::FUN1()
{
    if (!VAR3)
        VAR3 = VAR1::FUN2(this);
    return VAR3.FUN3();
}