bool VAR1::FUN1() {
  return !VAR2.FUN2() ||
      VAR3->FUN3();
}