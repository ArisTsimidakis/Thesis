static void FUN1(const VAR1::VAR2<VAR1::VAR3>& VAR4)
{
    VAR5* VAR6 = VAR7::FUN2(VAR4.FUN3());
    FUN4(VAR4, VAR6->FUN5());
}