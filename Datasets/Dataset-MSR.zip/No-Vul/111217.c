IntRect VAR1::FUN1(const VAR2& VAR3) const
{
    return VAR4->FUN1(VAR3);
}