VAR1::~FUN1() {
  if (VAR2)
    VAR2->FUN2(this);
  VAR3::FUN3()->FUN4()->FUN5(this);
}