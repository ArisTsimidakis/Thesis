VAR1::VAR2::~FUN1() {
  FUN2(VAR3::FUN3(VAR3::VAR4));
  delete FUN4();
}