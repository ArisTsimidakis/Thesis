VAR1::string16 VAR2::FUN1() const {
  return VAR3;
}