VAR1::VAR2 FUN1(SkColor VAR3) {
    return VAR4::FUN1(1, 1, VAR3);
  }