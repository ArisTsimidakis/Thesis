~FUN1() {
    VAR1.FUN2();
    if (VAR2)
      FUN3(VAR2);
    VAR3.FUN2();
    if (VAR4)
      FUN4(VAR4);
    FUN5(&VAR5);
    FUN6();
  }