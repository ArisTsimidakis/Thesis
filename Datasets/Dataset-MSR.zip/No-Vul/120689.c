void VAR1::FUN1(unsigned short VAR2)
{
    VAR3::FUN2(FUN3())->FUN4(this, (VAR2 | VAR4), VAR3::VAR5);
}