void VAR1::FUN1(const VAR2* VAR3) {
  FUN2(!VAR3->FUN3().FUN4());
  VAR4[VAR3->FUN5()].VAR5 = true;
  VAR6::FUN6()->FUN7(
      VAR7::VAR8,
      VAR9<const VAR2>(VAR3),
      VAR6::FUN8());
}