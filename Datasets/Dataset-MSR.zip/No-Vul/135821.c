void VAR1::FUN1(const VAR2&) {
  FUN2();
  FUN3();
}