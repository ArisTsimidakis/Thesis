int FUN1() const {
    return VAR1;
  }