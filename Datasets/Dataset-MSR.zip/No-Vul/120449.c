const VAR1<VAR2<VAR3> >& VAR4::FUN1()
{
    FUN2(FUN3());
    return *FUN4(this);
}