void VAR1::FUN1(CompatibilityMode VAR2) {
  if (VAR3 || VAR2 == VAR4)
    return;

  if (VAR4 == VAR5)
    VAR6::FUN2(*this, VAR7::VAR8);
  else if (VAR4 == VAR9)
    VAR6::FUN2(*this, VAR7::VAR10);

  VAR4 = VAR2;
  FUN3().FUN4();
}