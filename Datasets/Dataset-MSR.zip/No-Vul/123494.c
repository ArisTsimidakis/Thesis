void VAR1::FUN1(
    VAR2* VAR3,
    const VAR4& VAR5,
    const VAR4& VAR6,
    const VAR4& VAR7,
    const VAR4& VAR8,
    const VAR4& VAR9) {
  VAR3->FUN2("", VAR5);
  VAR3->FUN2("", VAR6);
  VAR3->FUN2("", VAR7);
  VAR3->FUN2("", VAR8);
  VAR3->FUN2("", VAR9);
  VAR3->FUN3("",
                      FUN4(VAR10::VAR11));
}