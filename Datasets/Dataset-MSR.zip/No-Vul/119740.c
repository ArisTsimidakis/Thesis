VAR1* VAR1::FUN1(VAR2::VAR3* VAR4,
                                       SkColor VAR5) {
  if (!VAR6)
    VAR6 = new FUN2(VAR4, VAR5);
  return VAR6;
}