void VAR1::FUN1(int VAR2,
                              const VAR3::VAR4& VAR5,
                              const VAR3::VAR6& VAR7) {
  FUN2(VAR8::FUN3(VAR8::VAR9));

  if (VAR2 == VAR10::VAR11) {
    VAR12* VAR13 = VAR14->FUN4();
    VAR15::VAR16* VAR17 = VAR3::VAR18<VAR15::VAR16>(VAR7).FUN5();
    if (*VAR17 == VAR19::VAR20) {
      FUN6(
          VAR13->FUN7(VAR19::VAR20));
    }
  } else {
    FUN8();
  }
}