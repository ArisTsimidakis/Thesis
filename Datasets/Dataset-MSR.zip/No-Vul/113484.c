void VAR1::FUN1(VAR2* VAR3)
{
#if FUN2(VAR4)
    if (!VAR3)
        return;
    if (VAR5->FUN3() && VAR3->FUN4(VAR6::VAR7)) {
        
        
        
        
        
        FUN5(VAR3);
    } else {
        
        
        if (FUN6() != FUN7()) {
            
            
            
            VAR8 = FUN8();

            
            
            
            VAR9 = VAR10->FUN9()->FUN10();

            
            
            
            VAR11 = FUN11();
        }

        
        
        
        
        FUN12()->FUN13();
        VAR12 = VAR3;
    }
#endif
}