void VAR1::FUN1(NotificationType VAR2,
                              const VAR3& VAR4,
                              const VAR5& VAR6) {
  if (VAR2 == VAR7::VAR8) {
    FUN2();
  }
}