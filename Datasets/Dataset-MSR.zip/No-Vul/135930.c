void VAR1::FUN1(const VAR2& VAR3)
{
    FUN2().FUN3();
    if (!VAR3.VAR4 && VAR3.VAR5 != VAR6)
        FUN2().FUN4(this);
    FUN5();
    if (VAR3.FUN6() && !FUN7()) {
        FUN8();
        FUN9();
    }
}