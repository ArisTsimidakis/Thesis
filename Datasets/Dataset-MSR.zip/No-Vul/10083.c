FUN1( VAR1 )
  {
    VAR2
  }