void VAR1::FUN1(int VAR2)
{
    FUN2()->FUN3();
    if (VAR3* VAR4 = FUN4())
        VAR4->FUN1(static_cast<int>(VAR2 * VAR4->FUN5()->FUN6()));
}