void FUN1() {
    if (VAR1) {
      VAR2::FUN2(NULL);
      VAR1 = false;
    }
  }