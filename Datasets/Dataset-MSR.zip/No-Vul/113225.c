VAR1::Rect VAR2::FUN1(
    VAR3::VAR4* VAR5) {
  
  VAR1::VAR6 FUN2(VAR1::VAR7::FUN3(VAR5).FUN2());
  int VAR8;
  if (VAR9 == VAR10) {
    VAR8 = VAR11;
  } else {
    int VAR12, VAR13;
    FUN4(&VAR12, &VAR13);
    VAR8 = VAR14::FUN5(VAR12, VAR13);
  }
  FUN6(VAR8, &VAR15);
  return VAR15;
}