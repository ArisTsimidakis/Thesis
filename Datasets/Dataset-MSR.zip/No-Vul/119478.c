void VAR1::FUN1()
{
    if (!VAR2->FUN2())
        return;
    VAR3::VAR4 FUN3(VAR5);
    VAR2->FUN4()->FUN5(true);
}