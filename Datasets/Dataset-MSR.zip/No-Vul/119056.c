void VAR1::FUN1(int32 VAR2) {
  FUN2(FUN3(), VAR2);
}