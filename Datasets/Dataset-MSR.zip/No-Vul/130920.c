static void FUN1(const VAR1::VAR2<VAR1::VAR3>& VAR4)
{
    VAR5 FUN2(VAR5::VAR6, "", "", VAR4.FUN3(), VAR4.FUN4());
    if (FUN5(VAR4.FUN6() < 1)) {
        VAR7.FUN7(VAR8::FUN8(1, VAR4.FUN6()));
        VAR7.FUN9();
        return;
    }
    VAR9* VAR10 = VAR11::FUN10(VAR4.FUN3());
    FUN11(int, VAR12, FUN12(VAR4[0], VAR7), VAR7);
    VAR10->FUN13(VAR12);
}