virtual void FUN1() {
    FUN2(VAR1.FUN3());
  }