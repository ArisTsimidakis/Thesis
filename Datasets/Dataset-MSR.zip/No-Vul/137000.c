String VAR1::FUN1() const {
  if (!FUN2() || FUN3())
    return FUN4();
  return VAR2->FUN5(*VAR3).VAR4;
}