void FUN1() {
    VAR1->FUN2(VAR2.FUN3());
  }