void VAR1::FUN1(
    uint32 VAR2) {
  VAR3* VAR4 = VAR5->FUN2();

  VAR6::CompositorFrameAck VAR7;
  if (!VAR8.FUN3()) {
    VAR7.VAR9.FUN4(VAR8);
  } else {
    FUN5(VAR10);
    VAR10->FUN6(&VAR7.VAR9);
  }
  FUN5(!VAR7.VAR9.FUN3());

  VAR3::FUN7(
      VAR4->FUN8(),
      VAR2,
      VAR4->FUN9()->FUN10(),
      VAR7);
}