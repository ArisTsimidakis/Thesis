VAR1::FUN1(Handle VAR2)
    : FUN2(VAR2), FUN3(true, false),
      FUN4(true, false) {
}