String VAR1::FUN1()
{
    String VAR2;
    FUN2()->FUN3(VAR3::VAR4::FUN4(), VAR3::VAR4::VAR5::FUN5(VAR2), VAR6);
    return VAR2;
}