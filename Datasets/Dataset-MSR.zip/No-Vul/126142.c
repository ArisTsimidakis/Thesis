bool VAR1::FUN1(VAR2::VAR3* VAR4) const {
  return VAR5 == VAR4;
}