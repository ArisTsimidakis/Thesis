void VAR1::FUN1(const VAR2& VAR3,
    bool VAR4,
    const VAR5& VAR6) {
  FUN2(VAR7::FUN3(VAR7::VAR8) ||
         VAR7::FUN3(VAR7::VAR9));
  FUN4(VAR10::FUN5(&VAR1::VAR11,
                               VAR12,
                               VAR3,
                               VAR4,
                               FUN6(VAR6)));
}