bool VAR1::FUN1() const
{
    const VAR2& VAR3 = FUN2(VAR4);
    return (FUN3(VAR5) && VAR3 == VAR6) || FUN4(VAR3, "");
}