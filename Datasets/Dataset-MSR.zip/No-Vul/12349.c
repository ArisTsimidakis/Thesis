FUN1(VAR1, VAR2)
{
	VAR3 *VAR4 = FUN2();
	VAR5 *VAR6 = (VAR5*)FUN3(object VAR7);
	VAR8 *VAR9 = FUN4(VAR6, 0 VAR7);

	if (FUN5() == VAR10) {
		return;
	}

	if (FUN6(VAR6, aht VAR7) == VAR10) {
		VAR11;
	} else {
		FUN7(FUN8(VAR9, &VAR6->VAR12) == VAR13);
	}
}