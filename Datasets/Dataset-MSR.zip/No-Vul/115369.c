void VAR1::FUN1(WKStringRef VAR2)
{
    if (!VAR3::FUN2().FUN3())
        return;
    if (!VAR3::FUN2().FUN4()->FUN5())
        return;

    StringBuilder VAR4;
    VAR4.FUN6("");
    VAR4.FUN7(FUN8(VAR2));
    VAR4.FUN7('');
    VAR3::FUN2().FUN9(VAR4.FUN10());
}