int VAR1::FUN1(VAR2* VAR3) const {
  if (!FUN2())
    return VAR4;
  return VAR5->FUN1(VAR3);
}