void VAR1::FUN1(VAR2& VAR3) {
  
  
  
  if (!VAR3.FUN2())
    return;
  
  
  if (!FUN3().FUN4())
    VAR4::FUN5(VAR5);
}