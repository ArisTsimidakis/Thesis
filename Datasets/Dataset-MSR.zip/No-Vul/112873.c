VAR1<VAR2::VAR3> VAR2::FUN1(
    const VAR4::VAR5& VAR6,
    const VAR4::VAR5& VAR7) {
  FUN2();
  return VAR8->FUN1(VAR6, VAR7);
}