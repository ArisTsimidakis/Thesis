void VAR1::FUN1(const VAR2& VAR3,
                                            VAR4& VAR5,
                                            const VAR6& VAR7,
                                            PaintInvalidationReason VAR8) {
  VAR9.FUN1(VAR5, VAR7);
  if (VAR10::FUN2())
    FUN3();
  if (VAR11)
    FUN4(VAR3, VAR5, VAR8);
}