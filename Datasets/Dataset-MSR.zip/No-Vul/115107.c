VAR1::FormatType VAR1::FUN1() {
  return FUN2(VAR2);
}