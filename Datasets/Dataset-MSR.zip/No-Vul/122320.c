void VAR1::FUN1(VAR2& VAR3)
{
    if (!VAR3.FUN2())
        return;
    VAR4->FUN3();
    VAR4 = VAR5::FUN4(*this);
    FUN5();
}