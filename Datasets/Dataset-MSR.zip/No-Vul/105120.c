void VAR1::FUN1(const VAR2& VAR3, VAR4& VAR5)
{
    VAR6 FUN2(FUN3());
    VAR6 FUN4(FUN5());
    if (VAR3 == "") {
        VAR7 = FUN6(VAR7);
        VAR8 = FUN7(VAR8);
    } else if (VAR3 == "") {
        VAR7 = FUN8(VAR7);
        VAR8 = FUN9(VAR8);
    } else if (VAR3 == "") {
        VAR7 = FUN10(VAR7);
        VAR8 = FUN11(VAR8);
    } else if (VAR3 == "") {
        VAR7 = FUN12(VAR7);
        VAR8 = FUN13(VAR8);
    } else
        return;
    FUN14(VAR7.FUN15().FUN16(), VAR7.FUN15().FUN17(), VAR5);
    FUN18(VAR8.FUN15().FUN16(), VAR8.FUN15().FUN17(), VAR5);
}