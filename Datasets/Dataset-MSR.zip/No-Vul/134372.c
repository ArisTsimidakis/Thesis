bool VAR1::FUN1(const VAR2::VAR3& VAR4) {
  return FUN2(VAR2::FUN3(VAR4, VAR2::FUN4(1, 1)));
}