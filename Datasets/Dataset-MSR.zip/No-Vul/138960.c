VAR1::FUN1() {
  WallpaperResolution VAR2 = FUN2();
  return VAR2 == VAR3 ? VAR4
                                                  : VAR5;
}