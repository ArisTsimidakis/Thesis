void VAR1::FUN1() {
  if (!VAR2)
    return;
  VAR2->FUN2();
}