void VAR1::FUN1(
     const VAR2& VAR3,
      FullscreenExitBubbleType VAR4) {
  if (VAR4 == VAR5) {
   VAR6.FUN2();
  } else if (VAR6.FUN3()) {
   VAR6->FUN4(VAR3, VAR4);
  } else {
    VAR6.FUN2(new FUN5(
        FUN6(VAR7),
        FUN7(),
        VAR3,
        VAR4));
  }
}