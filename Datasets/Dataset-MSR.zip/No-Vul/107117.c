VAR1::FUN1()
{
    FUN2();
    FUN3();
}