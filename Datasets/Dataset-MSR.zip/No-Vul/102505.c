bool VAR1::FUN1(
    VAR2<VAR3> VAR4,
    const VAR5& VAR6,
    bool VAR7,
    bool VAR8,
    VAR9* VAR10) {
  return FUN2(VAR11, VAR4, new FUN3(
      VAR6, VAR7, VAR8, VAR10));
}