static void FUN1(VAR1 *VAR2, char *str VAR3)
{
	char *VAR4;

	if (!(VAR4 = strchr(VAR5, ''))) {
		FUN2(VAR2, VAR5, 0 VAR6);
		return;
	}

	FUN2(VAR2, VAR5, strlen(VAR4+1) VAR6);
 }