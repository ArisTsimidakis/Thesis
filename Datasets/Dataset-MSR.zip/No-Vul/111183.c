void VAR1::FUN1()
{
    VAR2::FUN2()->FUN3(VAR3->VAR4);
}