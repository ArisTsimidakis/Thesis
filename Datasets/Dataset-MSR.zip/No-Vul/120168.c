void VAR1::FUN1(
    VAR2<VAR3> VAR4) {
  VAR5->FUN2(this);
  VAR5 = VAR4;
  VAR5->FUN3(this);
  FUN4();
}