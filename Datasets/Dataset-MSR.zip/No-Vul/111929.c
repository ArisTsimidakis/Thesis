void VAR1::FUN1(
    VAR2* VAR3) {
  FUN2(VAR4.FUN3(VAR3->FUN4()), 0U);
  VAR4[VAR3->FUN4()] =
      VAR3;
}