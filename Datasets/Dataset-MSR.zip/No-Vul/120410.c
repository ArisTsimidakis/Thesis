FUN1() :
      FUN2(
          VAR1::FUN3(&VAR2::VAR3,
                     VAR1::FUN4(this))) {}