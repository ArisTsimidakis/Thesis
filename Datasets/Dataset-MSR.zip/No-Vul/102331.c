void VAR1::FUN1(const VAR2::VAR3& VAR4,
                                           bool VAR5) {
  FUN2(VAR4, VAR6,
                      VAR7::FUN3(VAR5));
}