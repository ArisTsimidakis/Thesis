const char* VAR1::FUN1() const
{
    return VAR2.FUN2();
}