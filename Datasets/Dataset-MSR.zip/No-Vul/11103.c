FUN1(VAR1) 
{
	FUN2(VAR2) = FUN3(VAR3);

	if (VAR4 == VAR5) {
		FUN4();
	}

	return VAR6;
}