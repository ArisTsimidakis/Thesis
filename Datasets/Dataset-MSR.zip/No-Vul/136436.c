void FUN1(const VAR1& VAR2) {
    CompositorElementIdSet VAR3;
    FUN1(VAR2, VAR3);
  }