void VAR1::FUN1()
{
    if (FUN2())
        send(VAR2::VAR3::FUN3(VAR4::FUN4()), 0);
}