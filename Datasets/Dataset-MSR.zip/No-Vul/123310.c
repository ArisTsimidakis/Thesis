bool VAR1::FUN1() const {
  return true;
}