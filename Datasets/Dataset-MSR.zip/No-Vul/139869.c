const AutocompleteInput VAR1::FUN1(bool VAR2) const {
  
  
  return FUN2(VAR3::FUN3(), VAR3::VAR4::VAR5,
                           VAR6::FUN4(), FUN5(VAR7), VAR8,
                           VAR9, true, false, false,
                           true, false, FUN6()->FUN7());
}