virtual void FUN1() {
    VAR1.FUN1();
  }