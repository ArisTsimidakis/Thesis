void VAR1::FUN1()
{
    if (VAR2.FUN2() || VAR3.FUN3())
        return;
    VAR3.FUN4(0);
}