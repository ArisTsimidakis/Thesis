bool VAR1::FUN1() {
  VAR2::VAR3 FUN2(VAR4.FUN3());
  return VAR5 &&
      VAR5->FUN4() == VAR2::VAR6::FUN5();
}