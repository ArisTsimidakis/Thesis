String VAR1::FUN1(const VAR2& VAR3) const
{
    if (VAR3.FUN2())
        return VAR3;
    return VAR4->FUN1(VAR3);
}