void VAR1::FUN1() {
  VAR2 = true;
  FUN2();
}