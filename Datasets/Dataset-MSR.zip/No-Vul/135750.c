bool VAR1::FUN1() const {
  return FUN2().FUN3();
}