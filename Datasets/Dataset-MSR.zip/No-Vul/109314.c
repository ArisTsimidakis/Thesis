VAR1* VAR2::FUN1(VAR1* VAR3)
{
    if (VAR4) {
        if (VAR3)
            VAR5 = VAR3;
        return VAR6.FUN2();
    }
    return VAR3;
}