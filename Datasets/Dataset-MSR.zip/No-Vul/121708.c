void VAR1::FUN1(
    VAR2::VAR3* VAR4) {
  VAR4->FUN2(VAR4::VAR5,
                             true,
                             VAR2::VAR3::VAR6);
  VAR4->FUN2(VAR4::VAR7,
                             true,
                             VAR2::VAR3::VAR6);
  VAR4->FUN3(VAR4::VAR8,
                          VAR2::VAR3::VAR6);
  VAR4->FUN3(VAR4::VAR9,
                          VAR2::VAR3::VAR6);
}