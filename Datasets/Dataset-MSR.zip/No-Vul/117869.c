static void FUN1(VAR1::VAR2<VAR1::VAR3> VAR4, VAR1::VAR2<VAR1::VAR5> VAR6, const VAR1::VAR7& VAR8)
{
    FUN2("");
    VAR9* VAR10 = VAR11::FUN3(VAR8.FUN4());
    VAR12<short> VAR13 = VAR14<short>(VAR6);
    VAR10->FUN5(VAR13);
    return;
}