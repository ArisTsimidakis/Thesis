double VAR1::FUN1() const
{
    return VAR2 ? VAR2->FUN2() : 0;
}