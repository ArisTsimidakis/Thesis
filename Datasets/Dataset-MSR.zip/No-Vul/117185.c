void VAR1::FUN1(const VAR2* VAR3)
{
    VAR4.FUN2(VAR3);
}