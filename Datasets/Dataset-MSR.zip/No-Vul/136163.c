VAR1<VAR2> VAR3::FUN1(ParserSynchronizationPolicy VAR4)
{
    FUN2();

    FUN3();
    FUN4(!VAR5);

    FUN5(VAR6);

    if (!FUN6())
        VAR4 = VAR7;

    VAR8 = VAR4;
    VAR9 = FUN7();
    FUN8(VAR10);
    FUN9(VAR11);

    return VAR9;
}