void FUN1(int64 VAR1,
                      const VAR2& VAR3, const VAR4::VAR5& VAR6) {
  VAR4::string VAR7;
  FUN2(VAR3.FUN3(VAR6, &VAR7));
  int64 VAR8 = 0;
  FUN2(VAR9::FUN4(VAR7, &VAR8));
  FUN5(VAR1, VAR8);
}