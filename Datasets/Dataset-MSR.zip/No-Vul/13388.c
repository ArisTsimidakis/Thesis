static VAR1 FUN1(void *VAR2, hwaddr VAR3)
{
    FUN2("", (int) VAR3);

    return 0;
}