bool VAR1::VAR2::FUN1()
    const {
  return VAR3;
}