virtual void FUN1(double VAR1)
    {
    }