void VAR1::FUN1(
    const VAR2& VAR3,
    RevealExtentOption VAR4) {
  if (VAR5)
    return;
  if (!FUN2().FUN3().FUN4())
    return;
  FUN2().FUN3().FUN5(VAR3, VAR4);
}