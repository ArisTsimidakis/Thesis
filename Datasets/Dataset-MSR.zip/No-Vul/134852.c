void FUN1() {
    while (!FUN2()->FUN3())
      FUN4();
  }