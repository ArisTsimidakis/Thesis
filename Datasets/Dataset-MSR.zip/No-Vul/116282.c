void VAR1::FUN1()
{
    FUN2(VAR1);

    VAR2* VAR3 = VAR4->VAR5->FUN3();
    if (VAR3 && !VAR3->FUN4().FUN5() && VAR3->FUN6() != FUN7()) {
        
        
        
        
        
        VAR4->VAR5->FUN8(VAR3->FUN4());
        
        return;
    }

    const bool VAR6 = true;
    VAR4->VAR5->FUN1(VAR6);
}