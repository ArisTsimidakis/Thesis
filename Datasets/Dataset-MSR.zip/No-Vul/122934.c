void VAR1::FUN1() {
  if (!VAR2)
    FUN2(new FUN3(VAR3));
}