void FUN1(VAR1* VAR2, bool VAR3)
{
    FUN2(VAR2, VAR4);
    FUN3(VAR4, VAR5);

    VAR5->VAR6.VAR7 = VAR3;

    if (VAR3)
        FUN4(VAR2, "", 0);
}