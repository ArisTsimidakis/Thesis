string16 VAR1::FUN1(int VAR2, int VAR3) {
  switch (VAR3) {
    case VAR4:  
      return VAR5->FUN2(VAR2);

    case VAR6:  
      return VAR5->FUN3(VAR2);

    case VAR7:  
      return VAR5->FUN4(VAR2);

    case VAR8:  
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN7(VAR2);

    case VAR9:  
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN8(VAR2);

    case VAR10:  
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN9(VAR2);

    case VAR11:  
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN10(VAR2);

    case VAR12:
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN11(VAR2);

    case VAR13:  
      return VAR5->FUN12(VAR2);

    case VAR14:
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN13(VAR2);

    case VAR15:
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN14(VAR2);

    case VAR16:
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN15(VAR2);

    case VAR17:
      return VAR5->FUN16(VAR2);

    case VAR18:
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN17(VAR2);

    case VAR19:
      if (!VAR5->FUN5(VAR2))
        return FUN6();
      return VAR5->FUN18(VAR2);

    default:
      FUN19();
      return FUN6();
  }
}