void *FUN1(VAR1 *VAR2)
{
    if (*VAR2 >= VAR3)
        return NULL;

    return VAR4[*VAR2];
}