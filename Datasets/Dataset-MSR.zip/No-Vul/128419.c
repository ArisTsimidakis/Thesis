IntPoint VAR1::FUN1() const
{
    return -FUN2();
}