static void FUN1(const VAR1::VAR2<VAR1::VAR3>& VAR4)
{
    VAR5 FUN2(VAR5::VAR6, "", "", VAR4.FUN3(), VAR4.FUN4());
    VAR7* VAR8 = VAR9::FUN5(VAR4.FUN3());
    VAR10<VAR11> VAR12 = VAR8->FUN6(VAR13);
    if (VAR13.FUN7())
        return;
    FUN8(VAR4, VAR12.FUN9());
}