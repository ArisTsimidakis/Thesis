bool VAR1::FUN1(const VAR2::VAR3& VAR4) {
  VAR5 FUN2(VAR6);

  return (VAR7.FUN3(VAR4) != VAR7.FUN4());
}