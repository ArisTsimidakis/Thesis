void VAR1::FUN1(SyncEventCodes VAR2) {
  FUN2("", VAR2, VAR3);
}