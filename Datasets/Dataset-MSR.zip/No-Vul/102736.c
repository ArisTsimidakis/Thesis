FUN1()
        : FUN2(FUN3(10, 20))
        , FUN4(FUN3(40, 5))
        , FUN5(2, -1)
        , FUN6(0)
    {
    }