void VAR1::FUN1(const VAR2& VAR3,
                                             const VAR4::VAR5& VAR6) {
  VAR7->FUN2(VAR3, VAR6);
}