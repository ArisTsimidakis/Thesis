void VAR1::FUN1(const VAR2::VAR3& VAR4,
                                                      int32 VAR5,
                                                      const VAR6& VAR7,
                                                      const VAR8& VAR9) {
  if (VAR4.FUN2())
    FUN3(VAR9.FUN4());
  VAR10::FUN1(VAR4, VAR5, VAR7,
                                                  VAR9);
}