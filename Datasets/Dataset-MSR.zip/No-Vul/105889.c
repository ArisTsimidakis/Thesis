VAR1* FUN1(VAR2* VAR3, const VAR4& VAR5)
{
     return FUN1(VAR3->FUN2(), VAR5);
 }