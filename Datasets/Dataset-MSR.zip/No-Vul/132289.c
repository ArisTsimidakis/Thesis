VAR1::FUN1(
    VAR2::VAR3* VAR4) {
  if (!VAR4 || !VAR4->FUN2())
    return NULL;
  FUN3(!VAR5 || VAR5 == VAR4);
  return FUN4()->FUN5()->FUN6(
      this, VAR4);
}