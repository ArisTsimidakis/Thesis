void VAR1::FUN1()
{
    VAR2<VAR3> VAR4;
    FUN2(VAR5, VAR4);
    VAR5.FUN3();

    for (size_t VAR6 = 0; VAR6 < VAR4.FUN4(); ++VAR6) {
        VAR7<VAR8> VAR9 = VAR10.FUN5(VAR4[VAR6]);
        if (VAR9)
            VAR9->FUN6();
    }
}