VAR1::VAR2<VAR1::VAR3> FUN1(VAR4* VAR5)
    {
        return VAR6::FUN2(FUN3(), VAR5);
    }