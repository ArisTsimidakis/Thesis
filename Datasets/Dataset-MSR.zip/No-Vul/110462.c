VAR1::Error VAR2::FUN1(GLbitfield VAR3) {
  if (FUN2())
    return VAR1::VAR4;
  if (FUN3("")) {
    FUN4("", "", "", VAR5,
                                   "", VAR6);
    FUN5();
    FUN6(VAR3);
  }
  return VAR1::VAR7;
}