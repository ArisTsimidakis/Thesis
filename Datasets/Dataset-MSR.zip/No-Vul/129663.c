VAR1& VAR1::FUN1(double VAR2)
{
    
    return FUN2(FUN3(VAR2));
}