static void FUN1(VAR1::VAR2<VAR1::VAR3>, const VAR1::VAR4<VAR1::VAR5>& VAR6)
{
    FUN2("", "");
    VAR7::FUN3(VAR6);
    FUN2("", "");
}