bool FUN1(const VAR1* VAR2, const VAR3& VAR4,
                     const VAR3& VAR5, int VAR6) {
    return VAR2->FUN2()->FUN3(
        VAR2, VAR4, VAR5, VAR6, -1, NULL);
  }