static void FUN1(VAR1::VAR2<VAR1::VAR3>, VAR1::VAR2<VAR1::VAR4> VAR5, const VAR1::VAR6<void>& VAR7)
{
    FUN2("", "");
    VAR8* VAR9 = VAR8::FUN3(VAR7.FUN4()->FUN5());
    if (VAR9 && VAR9->FUN6()) {
        VAR1::VAR10<VAR1::VAR4> VAR11[] = { VAR5 };
        VAR9->FUN6()->FUN7("", 1, &VAR11[0], "");
    }
    VAR12::FUN8(VAR5, VAR7);
    FUN2("", "");
}