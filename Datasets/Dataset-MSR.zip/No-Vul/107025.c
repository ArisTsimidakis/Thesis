QPointF VAR1::FUN1(const VAR2& VAR3) const
{
    FUN2(const VAR1);
    return VAR4->VAR5->FUN3().FUN4(VAR3);
}