void VAR1::FUN1(bool VAR2) {
  if (VAR2)
    FUN2();
}