bool FUN1(const VAR1::VAR2* VAR3) {
  return VAR3->FUN1();
}