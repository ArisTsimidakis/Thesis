VAR1* VAR1::FUN1() {
  FUN2(VAR2);
  return VAR2;
}