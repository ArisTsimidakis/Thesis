void VAR1::FUN1(int VAR2) {
  FUN2(FUN3(VAR2));
  TabStripSelectionModel VAR3;
  VAR3.FUN4(FUN5());
  if (VAR4.FUN6(VAR2)) {
    if (VAR4.FUN7() == 1) {
      
      
      return;
    }
    VAR3.FUN8(VAR2);
    VAR3.FUN9(VAR2);
    if (VAR3.FUN10() == VAR2 ||
        VAR3.FUN10() == VAR5::VAR6)
      VAR3.FUN11(VAR3.FUN12()[0]);
  } else {
    VAR3.FUN13(VAR2);
    VAR3.FUN9(VAR2);
    VAR3.FUN11(VAR2);
  }
  FUN14(VAR3, VAR7);
}