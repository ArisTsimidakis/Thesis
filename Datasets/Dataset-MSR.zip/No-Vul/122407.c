bool VAR1::FUN1(VAR2* VAR3)
{
    if (!VAR4::FUN2().FUN3())
        return false;

    if (!FUN4(FUN5().FUN6())) {
        if (VAR3->FUN7() == "" || VAR3->FUN7() == "") {
            FUN8();
            
            
            
            if (!FUN9())
                return true;

            
            
            
            
            FUN10();
            if (VAR5* VAR6 = FUN11(FUN9()))
                VAR6->FUN12();
            VAR3->FUN13();
        }
        return true;
    }

    return false;
}