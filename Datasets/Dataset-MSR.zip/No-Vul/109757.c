void VAR1::FUN1()
{
    FUN2();

    
    
    if (!FUN3())
        return;

    if (VAR2* VAR3 = this->FUN4())
        VAR3->FUN5();
    FUN6();
}