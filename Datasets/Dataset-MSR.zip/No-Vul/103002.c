void VAR1::FUN1(
    const VAR2& VAR3) {
  FUN2(VAR2::VAR4, VAR3.FUN3());
  int VAR5 = FUN4();
  VAR6.FUN5(VAR3);
  
  FUN6(VAR5);
}