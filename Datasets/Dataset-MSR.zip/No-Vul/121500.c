void VAR1::FUN1(const VAR2::VAR3& VAR4,
                                              int32 VAR5,
                                              const VAR6& VAR7,
                                              const VAR8& VAR9) {
  if (VAR4.FUN2())
    FUN3();
  else
    VAR10 = VAR4;
  FUN4(VAR4.FUN2());
}