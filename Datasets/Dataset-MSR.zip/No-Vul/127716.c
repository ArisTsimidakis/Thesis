FUN1()
      : FUN2(VAR1::VAR2::VAR3),
        FUN3(VAR4::FUN4()),
        FUN5(new VAR5) {}