const VAR1* VAR2::FUN1(const VAR1* VAR3, const VAR4* VAR5, VAR6& VAR7)
{
    FUN2(VAR5, VAR5 != VAR3);

    VAR1* VAR8 = VAR3->FUN3();

    
    
    
    if (VAR8->FUN4()) {
        VAR9 FUN5(VAR3->FUN6());
        VAR10.FUN7(FUN8(VAR8)->FUN9());
        VAR7.FUN10(VAR3, VAR10);
    } else {
        VAR7.FUN10(VAR3, VAR3->FUN6());
    }

    return VAR8;
}