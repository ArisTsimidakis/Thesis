void VAR1::FUN1() {
  FUN2(!VAR2.FUN3());
  VAR2.FUN4(
      new FUN5(VAR3.FUN3(),
                                VAR4.FUN3(),
                                VAR5.FUN3(),
                                VAR6,
                                VAR7.FUN3()));
}