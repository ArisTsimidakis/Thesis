const VAR1& VAR2::FUN1() const
{
    switch (VAR3) {
        case VAR4: {
            FUN2(const VAR1, VAR5, ("", VAR1::VAR6));
            return VAR5;
        }
        case VAR7: {
            FUN2(const VAR1, VAR8, ("", VAR1::VAR6));
            return VAR8;
        }
        case VAR9: {
            FUN2(const VAR1, VAR10, ("", VAR1::VAR6));
            return VAR10;
        }
    }

    FUN3();
    return VAR11;
}