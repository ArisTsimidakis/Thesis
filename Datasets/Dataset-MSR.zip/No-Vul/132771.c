VAR1::~FUN1() {
  
  
  
  VAR2::VAR3 FUN2(true, false);
  VAR4->FUN3(
      VAR2::FUN4(&VAR2::VAR3::VAR5, VAR2::FUN5(&VAR6)));
  VAR6.FUN6();

  VAR7 = nullptr;
  while (!VAR8.FUN7()) {
    FUN8(VAR8.FUN9());
  }
}