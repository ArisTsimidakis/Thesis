void VAR1::FUN1()
{
    FUN2()->FUN3(this);

    VAR2 = VAR3;

    VAR4->FUN1();
}