void VAR1::VAR2::FUN1(
    VAR3* VAR4, int VAR5, bool VAR6) {
  VAR7->FUN2(VAR8, false);
}