int VAR1::FUN1() {
  VAR2* VAR3 = VAR4->FUN2();
  return VAR3->FUN3(VAR5::VAR6);
}