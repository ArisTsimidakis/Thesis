void VAR1::FUN1(
    VAR2::ModelTypeSet VAR3,
    bool VAR4) {
  if (!VAR5)
    return;

  FUN2(VAR6::FUN3(), VAR7);
  VAR5->FUN4(
      VAR3, VAR4);
}