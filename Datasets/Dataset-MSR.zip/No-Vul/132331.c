VAR1::VAR2* VAR3::FUN1() {
  if (!VAR4)
    VAR4.FUN2(new FUN3(FUN4()));

  return VAR4.FUN5();
}