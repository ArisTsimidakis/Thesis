void FUN1(SerializationTag VAR1)
    {
        FUN1(static_cast<VAR2>(VAR1));
    }