void VAR1::FUN1() {
  VAR2::FUN2()->FUN3(
      VAR3::VAR4,
      VAR5<VAR6>(VAR7->FUN4()),
      VAR2::FUN5());
}