long FUN1(const VAR1 *VAR2)
{
    if (VAR2 == NULL)
        return (0);
    return (VAR2->VAR3);
}