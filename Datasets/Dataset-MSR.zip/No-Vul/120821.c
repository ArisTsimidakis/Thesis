void VAR1::FUN1(bool VAR2) {
  FUN2(VAR3, !VAR2) << VAR4.FUN3()
                             << "";
 }