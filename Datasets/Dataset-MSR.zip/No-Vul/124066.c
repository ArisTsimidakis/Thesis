bool VAR1::FUN1(
    const VAR2& VAR3,
    const VAR2& VAR4,
    VAR5::VAR6* VAR7) {
  FUN2(VAR8::FUN3(VAR8::VAR9));
  VAR10* VAR11 = VAR10::FUN4(VAR7);
  return VAR11->FUN5()->
      FUN6(VAR3, VAR4);
}