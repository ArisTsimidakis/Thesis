int VAR1::FUN1(VAR2* VAR3)
{
    return FUN2().FUN3(VAR3);
}