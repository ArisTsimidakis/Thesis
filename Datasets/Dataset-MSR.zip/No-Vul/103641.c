bool VAR1::FUN1(VAR2* VAR3,
                                                          const VAR4& VAR5) {
  const VAR6* VAR7 = VAR8->FUN2();
  
  
  
  
  
  VAR4 FUN3(VAR3->FUN4().FUN5());
  if (VAR9.FUN6() && VAR3->FUN7())
    VAR9 = VAR3->FUN7()->FUN4().FUN5();

  
  
  
  
  if (VAR9 == VAR5) {
    bool VAR10 = !!VAR7->FUN8(VAR5);
    if (VAR10 != VAR8->FUN9())
      return true;
  }

  return !VAR7->FUN10(VAR9, VAR5);
}