ScriptPromise VAR1::FUN1(VAR2* VAR3)
{
    return VAR4->FUN2(VAR3->FUN3());
}