void VAR1::FUN1(int VAR2,
                                      int VAR3) {
  FUN2(VAR2, 0);
  VAR4::VAR5 FUN3(VAR2);
  VAR6 FUN4(VAR7);
  VAR4::VAR5 FUN5(VAR3);
  FUN6()->FUN7(
      "", VAR8, VAR9, VAR10);
}