bool VAR1::FUN1(const VAR2::VAR3& VAR4) {
  VAR5 =
      (VAR4.FUN2() || VAR4.FUN3()) &&
      (!FUN4() || (FUN5()->FUN6() == VAR6));
  if (VAR5) {
    
    
    
    
    FUN5()->FUN7(true);

    
    
    
    
    
    VAR7 = VAR8::VAR9::FUN8();
  }
  return VAR10::VAR11::FUN1(VAR4);
}