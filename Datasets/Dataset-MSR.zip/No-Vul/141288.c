void VAR1::FUN1(const VAR2* VAR3) {
  FUN2(VAR3);
  if (!FUN3(*VAR3))
    return;

  VAR4::VAR5 FUN4(VAR3);
  FUN5();
}