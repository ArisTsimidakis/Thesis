void VAR1::FUN1()
{
    VAR2 = true;
    FUN2().FUN3();
    VAR3::FUN4(this);
}