const VAR1& FUN1() {
    return VAR2->FUN2();
  }