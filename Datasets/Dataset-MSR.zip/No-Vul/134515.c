int VAR1::FUN1(const VAR2::VAR3& VAR4) {
  FUN2(VAR5);
  if (VAR5 != VAR6->FUN3())
    FUN4(VAR4);

  VAR7::WebDragOperationsMask VAR8 = FUN5(VAR4.FUN6());
  VAR9::Point VAR10 =
      VAR9::VAR11::FUN7(FUN8())->FUN9();
  VAR6->FUN3()->FUN10(
      VAR4.FUN11(), VAR10, VAR8,
      FUN12(VAR4.FUN13()));

  if (VAR12)
    VAR12->FUN14();

  return FUN15(VAR13);
}