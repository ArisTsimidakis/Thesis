static void FUN1(VAR1* VAR2,
                                     const VAR3<VAR4>&,
                                     jlong VAR5) {}