void VAR1::FUN1(bool VAR2, bool VAR3) {
  VAR4 = VAR3;
  if (VAR2 && VAR3)
    FUN2()->FUN3();
  else
    FUN2()->FUN4();
}