void FUN1(const VAR1::VAR2& VAR3) {
  VAR3.FUN2();
}