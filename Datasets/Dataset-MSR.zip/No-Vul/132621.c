void VAR1::FUN1() {
  WebPreferences VAR2 = FUN2()->FUN3();
  FUN4(VAR3, &VAR2);
  FUN2()->FUN5(VAR2);
  FUN6(new FUN7(FUN8(), VAR2));
}