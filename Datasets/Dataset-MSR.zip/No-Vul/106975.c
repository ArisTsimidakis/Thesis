qreal VAR1::FUN1() const
{
    FUN2(const VAR2);
    FUN3(VAR3->VAR4);
    return VAR3->VAR4->FUN1();
}