LayoutSize VAR1::FUN1() const
{
    if (!FUN2())
        return FUN3(-1, -1);
    return VAR2->FUN4(this);
}