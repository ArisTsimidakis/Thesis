const char** FUN1() {
  return const_cast<const char**>(VAR1);
}