virtual void FUN1(VAR1* VAR2) {
    VAR3::FUN1(VAR2);
    VAR2->FUN2(VAR4::VAR5);
  }