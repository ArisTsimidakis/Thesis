bool VAR1::FUN1(int32 VAR2,
                                          const VAR3::VAR4& VAR5,
                                          int32 VAR6,
                                          const VAR3::VAR4& VAR7) {
  if (!VAR8)
    return false;
  return VAR8->FUN1(this, VAR2, VAR5, VAR6,
                                        VAR7);
}