void VAR1::FUN1(const VAR2::VAR3& VAR4,
                                  VAR5::WindowShowState VAR6) {
  
  
  
  
  VAR7* VAR8 =
      VAR9::FUN2(FUN3());
  if (VAR8)
    VAR8->FUN4(VAR10, VAR4, VAR6);
}