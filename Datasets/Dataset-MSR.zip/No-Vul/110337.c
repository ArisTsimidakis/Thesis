void VAR1::FUN1(LengthComputable VAR2,
                               uint64_t VAR3,
                               uint64_t VAR4) {
  
  FUN2(VAR5);
  
  const VAR6::VAR7& VAR8 = VAR9.FUN3();
  FUN4(
      VAR10, VAR8, VAR2, VAR3, VAR4);
  FUN4(
      VAR11, VAR8, VAR2, VAR3, VAR4);

  
  FUN5(VAR12);
}