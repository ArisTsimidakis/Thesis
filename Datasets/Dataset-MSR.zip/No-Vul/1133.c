VAR1::~FUN1() {
  int VAR2;

  for (VAR2 = 0; VAR2 < VAR3; ++VAR2) {
    delete VAR4[VAR2];
  }
  delete VAR5;
  delete VAR6;
}