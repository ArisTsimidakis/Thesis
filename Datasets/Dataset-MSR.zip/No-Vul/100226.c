bool FUN1() const {
    return FUN2() || FUN3() || FUN4();
  }