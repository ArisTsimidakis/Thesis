VAR1* VAR2::FUN1() const
{
    return VAR3->FUN2();
}