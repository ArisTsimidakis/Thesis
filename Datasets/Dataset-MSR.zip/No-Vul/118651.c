void VAR1::FUN1(
    VAR2* VAR3) {
  FUN2(FUN3(), VAR3);
  VAR3->FUN4(this);

  VAR4 = VAR5::VAR6::FUN5();
  FUN6(VAR7,
                             VAR4 - VAR8);

  
  
  
  
  
  
  
  
  
  
  
  
  
  if (!FUN7()->FUN8()) {
    if (VAR9) {
      FUN9();
    } else if (!VAR10.FUN10()) {
      FUN11(VAR10);
    }
  }

  if (!VAR9) {
    
    
    
    
    
    FUN12();
  }
}