void VAR1::FUN1(int VAR2) {
  FUN2(VAR2, VAR3);
  FUN3(!VAR4.FUN4());

  
  CompletionCallback VAR5 = VAR4;
  VAR4.FUN5();
  VAR5.FUN6(VAR2);
}