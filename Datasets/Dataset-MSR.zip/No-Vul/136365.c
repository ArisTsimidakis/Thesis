void VAR1::FUN1(
    const VAR2& VAR3,
    PaintInvalidationReason VAR4) {
  String VAR5;
  if (VAR6)
    VAR5 = VAR6->VAR7.FUN2(&VAR3.VAR8.VAR9);
  FUN3(VAR3.VAR10, &VAR3.VAR8.VAR9, VAR4,
                        &VAR5);
}