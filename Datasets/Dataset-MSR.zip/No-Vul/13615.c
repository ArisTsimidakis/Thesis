static VAR1  FUN1( HB_Font      VAR2,
				 HB_UShort    VAR3,
				 VAR4*      VAR5,
				 void*        VAR6 )
{
  FUN2(VAR2);
  FUN2(VAR3);
  FUN2(VAR5);
  FUN2(VAR6);
  return FUN3(VAR7); 
}