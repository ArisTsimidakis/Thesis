VAR1::VAR2* VAR3::FUN1()
    const {
  return nullptr;
}