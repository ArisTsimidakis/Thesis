static int FUN1(const VAR1* VAR2, int VAR3, int VAR4, int VAR5)
{
    if (VAR2->FUN2())
        return VAR3 + VAR2->FUN3();
    return VAR4 - VAR5 - VAR2->FUN4();
}