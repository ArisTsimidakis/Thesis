void VAR1::VAR2::FUN1() {
  VAR3* VAR4 = FUN2(FUN3(VAR5));
  if (!VAR4)
      return;

  
  

  FUN4(VAR4, static_cast<double>(VAR6),
              static_cast<double>(VAR7));
  FUN5(VAR4, 1.0f, 1.0f, 1.0f, 0.0f);
  FUN6(VAR4, VAR8);
  FUN7(VAR4);
  FUN8(VAR4);
}