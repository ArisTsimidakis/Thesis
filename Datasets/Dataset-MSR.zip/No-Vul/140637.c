void VAR1::FUN1(double VAR2,
                                             float VAR3) {
  if (VAR4 != VAR2 || VAR5 != VAR3)
    VAR6->FUN2(VAR4 * VAR5);

  VAR7 = VAR8::FUN3(VAR9);
  int VAR10 = FUN4();
  if (VAR10 < VAR7.FUN5()) {
    VAR7.FUN6((VAR7.FUN5() - VAR10) / 2, 0);
    VAR7.FUN7(VAR10);
  }
  int VAR11 =
      FUN8() + (VAR12 * VAR5);
  if (VAR11 < VAR7.FUN9())
    VAR7.FUN10(VAR11);

  FUN11();
  VAR6->FUN12(VAR7.FUN13());
  VAR6->FUN14(VAR7.FUN15());

  if (!VAR13.FUN16())
    return;
  VAR14.FUN17(VAR8::FUN3(VAR8::FUN18(), VAR9));
}