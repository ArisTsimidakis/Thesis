void FUN1(EventType VAR1,
                             KeyboardCode VAR2,
                             int VAR3,
                             VAR4* VAR5) {
  FUN2(VAR5);
  VAR6* VAR7 = FUN3();
  XKeyEvent VAR8;
  VAR8.VAR1 = FUN4(VAR1);
  FUN5(0, VAR8.VAR1);
  VAR8.VAR9 = 0;
  VAR8.VAR10 = 0;
  VAR8.VAR7 = VAR7;
  VAR8.VAR11 = 0;
  VAR8.VAR12 = 0;
  VAR8.VAR13 = 0;
  VAR8.VAR14 = 0;
  VAR8.VAR15 = 0;
  VAR8.VAR16 = 0;
  VAR8.VAR17 = 0;
  VAR8.VAR18 = 0;
  VAR8.VAR19 = FUN6(VAR3);
  VAR8.VAR20 = FUN7(VAR2, VAR3, VAR7);
  VAR8.VAR21 = 1;
  VAR5->VAR1 = VAR8.VAR1;
  VAR5->VAR22 = VAR8;
}