void VAR1::FUN1()
{
    if (VAR2->FUN2())
        FUN3(FUN4());

    FUN5(false);
    FUN6(FUN7(VAR3));
    VAR4 = true;
}