void VAR1::FUN1(VAR2* VAR3)
{
    const VAR4& VAR5 = VAR3->FUN2();
    if (VAR5 == "") {
        FUN3().FUN4(true);
        
        
    }
}