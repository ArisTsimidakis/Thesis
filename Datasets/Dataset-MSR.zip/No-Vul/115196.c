string16 VAR1::FUN1() const {
  
  VAR2::VAR3* VAR4 = VAR5->FUN2();
  if (VAR4->FUN3(VAR2::VAR3::FUN4(),
                                   VAR2::VAR3::VAR6)) {
    string16 VAR7;
    VAR4->FUN5(VAR2::VAR3::VAR6, &VAR7);
    
    
    
    
    
    
    return FUN6(FUN7(VAR7, true));
  }

  
  
  
  
  
  
  
  if (VAR4->FUN3(VAR2::VAR3::FUN8(),
                                   VAR2::VAR3::VAR6)) {
    VAR8::string VAR9;
    VAR4->FUN9(NULL, &VAR9);
    
    VAR10 FUN10(VAR9);
    if (VAR11.FUN11())
      return FUN6(FUN12(VAR11.FUN13()));
  }

  return FUN14();
}