void VAR1::FUN1(
    GLint VAR2, GLsizei VAR3, const VAR4* VAR5) {
  GLenum VAR6 = 0;
  if (!FUN2(VAR2, "", &VAR6, &VAR3)) {
    return;
  }
  FUN3(VAR2, VAR3, VAR5);
}