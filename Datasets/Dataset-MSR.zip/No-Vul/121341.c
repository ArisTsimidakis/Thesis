void FUN1() {
    VAR1* VAR2 = VAR1::FUN2();
    VAR3::VAR4 FUN3(
        VAR3::VAR5,
        VAR3::VAR6<VAR3::VAR7>(VAR8->FUN4()));
    VAR2->FUN5();
    VAR9.FUN6();
  }