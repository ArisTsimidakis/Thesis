int VAR1::FUN1() {
  return reinterpret_cast<int>(&VAR2);
}