PP_Resource VAR1::FUN1(
    const VAR2& VAR3,
    VAR4::SharedMemoryHandle VAR5,
    uint32_t VAR6) {
  return (new FUN2(VAR3, VAR5, VAR6))->FUN3();
}