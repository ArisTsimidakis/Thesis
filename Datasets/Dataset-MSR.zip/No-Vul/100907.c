static VAR1* FUN1(const VAR2* VAR3,
                                            const int VAR4) {
  VAR1* VAR5 = new FUN2();

  const int VAR6 = VAR3->FUN3();
  if (VAR4 >= VAR6)
     return VAR5;

  int VAR7 = VAR3->FUN4(VAR4, 0);
  VAR8::VAR9<int, int> VAR10;
  VAR10 = VAR3->FUN5(VAR7);
  int VAR11 = VAR10.VAR12;

  VAR5->FUN6("", VAR7);
  VAR5->FUN7("",
                  VAR3->FUN8(VAR7));

  
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);
  FUN9(VAR3, "", VAR7, 1, VAR5);

  
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);
  FUN9(VAR3, "", VAR7, VAR11, VAR5);

  return VAR5;
}