void VAR1::VAR2::FUN1(
    const VAR3::VAR4& VAR5) {
  
  VAR6 FUN2(VAR7, FUN3());
  VAR8* VAR9 = VAR10.FUN4();

  
  
  VAR9->FUN5(VAR5);
}