void VAR1::FUN1(VAR2::VAR3* VAR4) {
  VAR5 = VAR4;
  VAR6 = new VAR2::FUN2(VAR7::FUN3());
  FUN4(VAR6);

  
  
  
  VAR8* VAR9 =
      VAR8::FUN5(VAR7::FUN3(),
                          NULL,
                          VAR10,
                          NULL,
                          NULL);
  VAR11.FUN6(new FUN7(VAR9));
  VAR6->FUN8(VAR9);

  VAR9->FUN9(this);
  VAR12::FUN10(
      VAR9->FUN11(),
      VAR7::FUN3());

  VAR13.FUN12(this,
                 VAR14::VAR15,
                 VAR14::VAR16<VAR8>(VAR9));
}