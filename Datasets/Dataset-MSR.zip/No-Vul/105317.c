FUN1()
      : FUN2(&VAR1),
        FUN3(new FUN4()) {
    VAR2.FUN5(this);
  }