void VAR1::FUN1(
    VAR2* VAR3, const int VAR4, const char* VAR5) {
  if (!VAR6->FUN2(VAR3))
    return;

  VAR7<VAR8> FUN3(new FUN4());
  VAR9->FUN5(VAR10::FUN6(VAR4));

  FUN7(VAR3, VAR5, VAR9.FUN8(),
                 VAR11::VAR12);
 }