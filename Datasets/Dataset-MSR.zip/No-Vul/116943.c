void VAR1::FUN1(int32 VAR2,
                                                  int32 VAR3,
                                                  int32 VAR4) {
  FUN2(VAR2, FUN3());
  VAR5* VAR6 = VAR7.FUN4(VAR3);
  if (!VAR6)
    return;
  VAR6->FUN5(new FUN6(VAR4));
  VAR7.FUN7(VAR3);
}