void VAR1::FUN1(
    VAR2::VAR3::Error VAR4) {
  if (VAR5) {
    
    
    VAR5->FUN2();
    if (!FUN3(VAR5))
      FUN4(VAR6) << "";
    VAR5 = NULL;
  }
  if (!FUN3(new FUN5(
          VAR7, VAR4))) {
    FUN4(VAR6) << ""
                << "";
  }
}