const char* FUN1(VAR1::SafetyState VAR2) {
  switch (VAR2) {
    case VAR1::VAR3:
      return "";
    case VAR1::VAR4:
      return "";
    case VAR1::VAR5:
      return "";
    default:
      FUN2() << "" << VAR2;
      return "";
  };
}