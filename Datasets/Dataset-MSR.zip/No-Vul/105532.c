bool FUN1(
    VAR1* VAR2,
    const VAR3::VAR4& VAR5,
    VAR3::VAR4* VAR6) {
  DictionaryValue VAR7;
  VAR7.FUN2("", "");
  VAR7.FUN3("", true);
  VAR7.FUN2("", VAR5);
  DictionaryValue VAR8;
  return FUN4(VAR2, VAR7, &VAR8, VAR6);
}