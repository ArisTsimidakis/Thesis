void VAR1::FUN1(VAR2* VAR3, VAR2* VAR4, VAR5& VAR6)
{
    
    VAR7<VAR2> FUN2(VAR3);

    if (!VAR3 || !(VAR3->FUN3(VAR8) || VAR3->FUN3(VAR9)))
        return;

    FUN4(VAR3, VAR4, VAR6);
    FUN5();
}