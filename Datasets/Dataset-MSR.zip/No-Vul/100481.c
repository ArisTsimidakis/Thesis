void VAR1::FUN1(bool VAR2)
{
    VAR3->FUN1(VAR2);
}