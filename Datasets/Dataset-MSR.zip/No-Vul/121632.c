VAR1<VAR2> VAR3::FUN1() const
{
    if (VAR4)
        return VAR2::FUN2(VAR4->FUN3(), VAR4, VAR5, VAR4, VAR6);
    
    return VAR2::FUN2(VAR7->FUN3(), VAR7, VAR8, VAR7, VAR8);
}