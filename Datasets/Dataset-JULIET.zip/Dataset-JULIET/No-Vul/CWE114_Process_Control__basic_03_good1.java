class good1_class{
    private void good1() throws Throwable
        {
            if (5 != 5)
            {
                /* INCIDENTAL: CWE 561 Dead Code, the code below will never run */
                IO.writeLine("Benign, fixed string");
            }
            else
            {
    
                String root;
                String libraryName = "test.dll";
    
                if(System.getProperty("os.name").toLowerCase().indexOf("win") >= 0)
                {
                    /* running on Windows */
                    root = "C:\\libs\\";
                }
                else
                {
                    /* running on non-Windows */
                    root = "/home/user/libs/";
                }
    
                /* FIX: Use System.load() which allows you to specify a full path to the library */
                System.load(root + libraryName);
    
            }
        }
};