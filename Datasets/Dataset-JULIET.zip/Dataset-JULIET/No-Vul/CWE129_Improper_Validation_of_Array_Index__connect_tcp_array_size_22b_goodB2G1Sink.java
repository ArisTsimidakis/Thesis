class goodB2G1Sink_class{
    public void goodB2G1Sink(int data ) throws Throwable
        {
            if (CWE129_Improper_Validation_of_Array_Index__connect_tcp_array_size_22a.goodB2G1PublicStatic)
            {
                /* INCIDENTAL: CWE 561 Dead Code, the code below will never run
                 * but ensure data is inititialized before the Sink to avoid compiler errors */
                data = 0;
            }
            else
            {
    
                /* Need to ensure that the array is of size > 3  and < 101 due to the GoodSource and the large_fixed BadSource */
                int array[] = null;
    
                /* FIX: Verify that data is non-negative AND greater than 0 */
                if (data > 0)
                {
                    array = new int[data];
                }
                else
                {
                    IO.writeLine("Array size is negative");
                }
    
                /* do something with the array */
                array[0] = 5;
                IO.writeLine(array[0]);
    
            }
        }
};